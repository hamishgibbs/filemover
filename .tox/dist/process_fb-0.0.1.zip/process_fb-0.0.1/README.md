# fbprocess

Package for scaffolding a data processing pipeline from Facebook Data for Good.

Combines functionality in pull_fb and fbutils Python packages.

### Installation

This is too much for now - just going to create a working processing repo first.
